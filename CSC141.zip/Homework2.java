import java.util.Scanner;
public class Homework2
{
   public static void main(String[]args)
   {
      //define variables
      double score1,score2,score3;
      
      //input
      Scanner input = new Scanner(System.in);
      System.out.println("What is the first test score?");
      score1 = input.nextDouble();
      System.out.println("What is the second test score?");
      score2 = input.nextDouble();
      System.out.println("What is the third test score?");
      score3 = input.nextDouble();
      
      //output
      double average = (score1+score2+score3)/3;
      System.out.println("The average of test scores is "+average);
      
   }
}