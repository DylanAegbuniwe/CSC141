import java.util.*;
public class OddTriangle
{
   public static void main(String[] args) 
   {
      Scanner input = new Scanner(System.in);
      int r,x,y,z;
      System.out.println("How many rows?");
      r = input.nextInt();
      for(x=1; x<=r; x++)
      {
         for(y=4; y>=x; y--)
         {
            System.out.print(" ");
         }
         for(z=1; z<=(2*x-1); z++)
         {
            System.out.print("$");
         }
         System.out.println("");
      }
   }
}