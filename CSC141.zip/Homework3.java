import javax.swing.JOptionPane;
public class Homework3
{
   public static void main(String[]args)
   {
      //define variable
      int number;
      String temp;
      
      //input
      temp = JOptionPane.showInputDialog("How many books did you purchase this month?");
      number = Integer.parseInt (temp);
      
      //switch
      switch(number)
      {
         case 0: JOptionPane.showMessageDialog(null, "You have 0 points.");break;
         case 1: JOptionPane.showMessageDialog(null, "You have 5 points.");break;
         case 2: JOptionPane.showMessageDialog(null, "You have 15 points.");break;
         case 3: JOptionPane.showMessageDialog(null, "You have 30 points.");break;     
         default: if(number>=4)
         {
            JOptionPane.showMessageDialog(null, "You have 60 points.");break;
         }
         else
         {
            JOptionPane.showMessageDialog(null, "Invalid input.");
         }
      }
      System.exit(0);
   }
} 