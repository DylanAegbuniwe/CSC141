public class HW1 {

    public static void main(String[] args) 
    {
        double g = 5.0d;
        int h;
        System.out.println(g);
            
}
}